 'use strict';
 
 function getOrigin(url) {
   try {
     return new URL(url).origin;
   } catch (_) {
     return null;
   }
 }
 
 function isDefaultEnabledForUrl(url) {
   try {
     const hostname = new URL(url).hostname.toLowerCase();
     return hostname.includes('stayntouch') || hostname.includes('protel') || hostname.includes('mews') || hostname.includes ('visbook');
   } catch (_) {
     return false;
   }
 }
 
 function getEffectiveEnabled(enabledOrigins, origin, url) {
   const autoEnabled = isDefaultEnabledForUrl(url);
   const hasStored = Object.prototype.hasOwnProperty.call(enabledOrigins, origin);
   return hasStored ? !!enabledOrigins[origin] : autoEnabled;
 }
 
 function updateActionBadge(tabId, enabled) {
   if (!chrome.action || !chrome.action.setBadgeText) return;
   chrome.action.setBadgeText({ tabId, text: enabled ? 'ON' : '' });
   if (chrome.action.setBadgeBackgroundColor) {
     chrome.action.setBadgeBackgroundColor({
       tabId,
       color: enabled ? '#4caf50' : '#999999'
     });
   }
 }

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: 'open-member-insight',
    title: 'Open in Loyco Member Insight',
    contexts: ['selection', 'editable']
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId !== 'open-member-insight' || !tab?.id) return;
  chrome.tabs.sendMessage(tab.id, {
    action: 'openMemberInsightFromContext',
    selectionText: info.selectionText || null
  }).then((response) => {
    if (response?.url) chrome.tabs.create({ url: response.url });
  }).catch(() => {});
});

 chrome.action.onClicked.addListener((tab) => {
   if (!tab?.id || !tab.url) return;
   const origin = getOrigin(tab.url);
   if (!origin) return;
  
   chrome.storage.sync.get({ enabledOrigins: {} }, (data) => {
     const enabledOrigins = data.enabledOrigins || {};
     const currentlyEnabled = getEffectiveEnabled(enabledOrigins, origin, tab.url);
     const nextEnabled = !currentlyEnabled;
  
     enabledOrigins[origin] = nextEnabled;
     chrome.storage.sync.set({ enabledOrigins }, () => {
       updateActionBadge(tab.id, nextEnabled);
       chrome.tabs.sendMessage(tab.id, {
         action: 'setEnabled',
         enabled: nextEnabled
       }).catch(() => {});
     });
   });
 });

 chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
   if (changeInfo.status !== 'complete' || !tab?.url) return;
   const origin = getOrigin(tab.url);
   if (!origin) return;
  
   chrome.storage.sync.get({ enabledOrigins: {} }, (data) => {
     const enabledOrigins = data.enabledOrigins || {};
     const isEnabled = getEffectiveEnabled(enabledOrigins, origin, tab.url);
     updateActionBadge(tabId, isEnabled);
     if (isEnabled) {
       chrome.tabs.sendMessage(tabId, {
         action: 'setEnabled',
         enabled: true
       }).catch(() => {});
     }
   });
 });
  
 chrome.tabs.onActivated.addListener(({ tabId }) => {
   chrome.tabs.get(tabId, (tab) => {
     if (chrome.runtime.lastError || !tab?.url) return;
     const origin = getOrigin(tab.url);
     if (!origin) return;
     chrome.storage.sync.get({ enabledOrigins: {} }, (data) => {
       const enabledOrigins = data.enabledOrigins || {};
       const isEnabled = getEffectiveEnabled(enabledOrigins, origin, tab.url);
       updateActionBadge(tabId, isEnabled);
     });
   });
 });
