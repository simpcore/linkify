 'use strict';
 
 function getOrigin(url) {
   try {
     return new URL(url).origin;
   } catch (_) {
     return null;
   }
 }
 
 function isDefaultEnabledForUrl(url) {
   try {
     const hostname = new URL(url).hostname.toLowerCase();
     return hostname.includes('stayntouch') || hostname.includes('protel') || hostname.includes('mews') || hostname.includes ('visbook');
   } catch (_) {
     return false;
   }
 }
 
 function getEffectiveEnabled(enabledOrigins, origin, url) {
   const autoEnabled = isDefaultEnabledForUrl(url);
   const hasStored = Object.prototype.hasOwnProperty.call(enabledOrigins, origin);
   return hasStored ? !!enabledOrigins[origin] : autoEnabled;
 }
 
 function updateActionBadge(tabId, enabled) {
   if (!chrome.action || !chrome.action.setBadgeText) return;
   chrome.action.setBadgeText({ tabId, text: enabled ? 'ON' : '' });
   if (chrome.action.setBadgeBackgroundColor) {
     chrome.action.setBadgeBackgroundColor({
       tabId,
       color: enabled ? '#4caf50' : '#999999'
     });
   }
 }

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: 'open-member-insight',
    title: 'Open in Loyco Member Insight',
    // Show on all right-click contexts so it is available
    // even when clicking already-linkified text or other elements.
    contexts: ['all']
  });
});

/** Always build the tab URL here so it stays absolute; relative strings resolve against the current tab (e.g. Mews) and break. */
const MEMBER_INSIGHT_TAB_BASE = 'https://memberinsight.loyalty.loyall.no/login/?member=';

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId !== 'open-member-insight' || !tab?.id) return;
  const payload = {
    action: 'openMemberInsightFromContext',
    selectionText: info.selectionText ?? null
  };
  const onResponse = (response) => {
    if (chrome.runtime.lastError) {
      return;
    }
    if (response && typeof response.member === 'string' && response.member.length > 0) {
      chrome.tabs.create({ url: MEMBER_INSIGHT_TAB_BASE + encodeURIComponent(response.member) });
    }
  };
  // With all_frames content scripts, broadcasting lets another frame respond first with {}.
  if (typeof info.frameId === 'number') {
    chrome.tabs.sendMessage(tab.id, payload, { frameId: info.frameId }, onResponse);
  } else {
    chrome.tabs.sendMessage(tab.id, payload, onResponse);
  }
});

 chrome.action.onClicked.addListener((tab) => {
   if (!tab?.id || !tab.url) return;
   const origin = getOrigin(tab.url);
   if (!origin) return;
 
   chrome.storage.sync.get({ enabledOrigins: {} }, (data) => {
     const enabledOrigins = data.enabledOrigins || {};
     const currentlyEnabled = getEffectiveEnabled(enabledOrigins, origin, tab.url);
     const nextEnabled = !currentlyEnabled;
 
     enabledOrigins[origin] = nextEnabled;
     chrome.storage.sync.set({ enabledOrigins }, () => {
       updateActionBadge(tab.id, nextEnabled);
       chrome.tabs.sendMessage(
         tab.id,
         {
           action: 'setEnabled',
           enabled: nextEnabled
         },
         () => {
           // Ignore errors when tab no longer exists.
           void chrome.runtime.lastError;
         }
       );
     });
   });
 });

 chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
   if (changeInfo.status !== 'complete' || !tab?.url) return;
   const origin = getOrigin(tab.url);
   if (!origin) return;
 
   chrome.storage.sync.get({ enabledOrigins: {} }, (data) => {
     const enabledOrigins = data.enabledOrigins || {};
     const isEnabled = getEffectiveEnabled(enabledOrigins, origin, tab.url);
     updateActionBadge(tabId, isEnabled);
     if (isEnabled) {
       chrome.tabs.sendMessage(
         tabId,
         {
           action: 'setEnabled',
           enabled: true
         },
         () => {
           // Ignore errors when tab no longer exists.
           void chrome.runtime.lastError;
         }
       );
     }
   });
 });
  
 chrome.tabs.onActivated.addListener(({ tabId }) => {
   chrome.tabs.get(tabId, (tab) => {
     if (chrome.runtime.lastError || !tab?.url) return;
     const origin = getOrigin(tab.url);
     if (!origin) return;
     chrome.storage.sync.get({ enabledOrigins: {} }, (data) => {
       const enabledOrigins = data.enabledOrigins || {};
       const isEnabled = getEffectiveEnabled(enabledOrigins, origin, tab.url);
       updateActionBadge(tabId, isEnabled);
     });
   });
 });
